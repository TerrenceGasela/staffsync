import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  LayoutDashboard, CalendarDays, ClipboardList, Users, BarChart3,
  Settings, Bell, Search, ChevronDown, Plus, CheckCircle2,
  Clock3, XCircle, Menu, LogOut, UserRound, Building2, ShieldCheck
} from "lucide-react";
import "./styles.css";

const logoMark = (
  <div className="logo-mark" aria-label="StaffSync">
    <span className="logo-s">S</span><span className="logo-v">✓</span>
  </div>
);

const initialRequests = [
  { id: 1, employee: "Thabo Mokoena", type: "Annual Leave", from: "08 Sep 2026", to: "10 Sep 2026", days: 3, status: "Pending" },
  { id: 2, employee: "Nandi Dlamini", type: "Family Responsibility", from: "11 Sep 2026", to: "11 Sep 2026", days: 1, status: "Pending" },
  { id: 3, employee: "Sipho Khumalo", type: "Annual Leave", from: "21 Sep 2026", to: "25 Sep 2026", days: 5, status: "Approved" },
];

function App() {
  const [page, setPage] = useState("Dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [role, setRole] = useState("Employee");
  const [requests, setRequests] = useState(initialRequests);
  const [showLeave, setShowLeave] = useState(false);
  const [toast, setToast] = useState("");

  const employeeRequests = useMemo(
    () => requests.filter(r => r.employee === "You"),
    [requests]
  );

  const nav = role === "HR/Admin"
    ? ["Dashboard", "Employees", "Leave Requests", "Reports", "Calendar", "Settings"]
    : role === "Manager"
    ? ["Dashboard", "Team Leave", "Leave Requests", "Calendar", "Settings"]
    : ["Dashboard", "My Leave", "Request Leave", "Calendar", "Settings"];

  const notify = (message) => {
    setToast(message);
    setTimeout(() => setToast(""), 2600);
  };

  const submitLeave = (e) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const request = {
      id: Date.now(),
      employee: "You",
      type: form.get("type"),
      from: form.get("from"),
      to: form.get("to"),
      days: Number(form.get("days") || 1),
      status: "Pending"
    };
    setRequests([request, ...requests]);
    setShowLeave(false);
    notify("Leave request submitted successfully.");
    setPage("My Leave");
  };

  const updateRequest = (id, status) => {
    setRequests(requests.map(r => r.id === id ? {...r, status} : r));
    notify(`Request ${status.toLowerCase()}.`);
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand">
          {logoMark}
          <div>
            <div className="brand-name">StaffSync</div>
            <div className="brand-tag">Syncing People. Simplifying Work.</div>
          </div>
        </div>

        <div className="workspace">
          <div className="workspace-icon"><Building2 size={16}/></div>
          <div>
            <div className="workspace-label">WORKSPACE</div>
            <div className="workspace-name">Acme South Africa</div>
          </div>
          <ChevronDown size={15} />
        </div>

        <nav>
          {nav.map(item => (
            <button
              key={item}
              className={`nav-item ${page === item ? "active" : ""}`}
              onClick={() => { setPage(item); setMobileOpen(false); }}
            >
              {item === "Dashboard" && <LayoutDashboard size={19}/>}
              {(item === "My Leave" || item === "Team Leave" || item === "Leave Requests" || item === "Request Leave") && <ClipboardList size={19}/>}
              {item === "Employees" && <Users size={19}/>}
              {item === "Calendar" && <CalendarDays size={19}/>}
              {item === "Reports" && <BarChart3 size={19}/>}
              {item === "Settings" && <Settings size={19}/>}
              <span>{item}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="security-note">
            <ShieldCheck size={18}/>
            <div><strong>Secure workspace</strong><span>Role-based access enabled</span></div>
          </div>
          <button className="logout"><LogOut size={17}/> Sign out</button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)}><Menu/></button>
          <div className="searchbox"><Search size={18}/><input placeholder="Search StaffSync..." /></div>
          <div className="top-actions">
            <button className="icon-btn" onClick={() => notify("You have 3 new notifications.")}><Bell size={19}/><span className="dot"/></button>
            <div className="role-switch">
              <select value={role} onChange={e => {setRole(e.target.value); setPage("Dashboard")}}>
                <option>Employee</option>
                <option>Manager</option>
                <option>HR/Admin</option>
              </select>
            </div>
            <div className="profile">
              <div className="avatar">NM</div>
              <div className="profile-text"><strong>Nobuhle Makhanya</strong><span>{role}</span></div>
              <ChevronDown size={15}/>
            </div>
          </div>
        </header>

        <section className="content">
          {page === "Dashboard" && <Dashboard role={role} onRequest={() => setShowLeave(true)} requests={requests} updateRequest={updateRequest}/>}
          {page === "My Leave" && <MyLeave requests={requests} onRequest={() => setShowLeave(true)} />}
          {page === "Request Leave" && <LeaveForm onSubmit={submitLeave} />}
          {page === "Leave Requests" && <Requests requests={requests} updateRequest={updateRequest} />}
          {page === "Employees" && <Employees />}
          {page === "Calendar" && <Calendar />}
          {page === "Team Leave" && <Requests requests={requests} updateRequest={updateRequest} teamOnly />}
          {page === "Reports" && <Reports />}
          {page === "Settings" && <SettingsPage />}
        </section>
      </main>

      {showLeave && <Modal onClose={() => setShowLeave(false)}><LeaveForm onSubmit={submitLeave}/></Modal>}
      {toast && <div className="toast"><CheckCircle2 size={18}/>{toast}</div>}
    </div>
  );
}

function PageHeader({ eyebrow, title, subtitle, action }) {
  return <div className="page-header">
    <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>
    {action}
  </div>
}

function Dashboard({role,onRequest,requests,updateRequest}) {
  const isEmployee = role === "Employee";
  return <>
    <PageHeader eyebrow="GOOD MORNING, NOBUHLE" title="Your workspace" subtitle="Here’s what’s happening with your time off and team." action={
      isEmployee ? <button className="primary-btn" onClick={onRequest}><Plus size={18}/> Request leave</button> : null
    }/>
    <div className="stats">
      <Stat icon={<CalendarDays/>} label="Annual leave" value="18 days" hint="remaining" />
      <Stat icon={<Clock3/>} label="Pending requests" value={isEmployee ? "1" : "2"} hint="awaiting action" />
      <Stat icon={<CheckCircle2/>} label="Approved this year" value="7" hint="requests" />
      <Stat icon={<Users/>} label="Team members" value="24" hint={isEmployee ? "in your company" : "in your team"} />
    </div>

    <div className="grid-2">
      <div className="card">
        <div className="card-head"><div><h2>Leave balance</h2><span>2026 entitlement</span></div><button className="link-btn">View details</button></div>
        <div className="balance">
          <div className="balance-circle"><strong>18</strong><span>days left</span></div>
          <div className="balance-bars">
            <Balance label="Annual Leave" used="12 of 30" pct={40}/>
            <Balance label="Sick Leave" used="2 of 30" pct={7}/>
            <Balance label="Family Responsibility" used="1 of 3" pct={33}/>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head"><div><h2>Upcoming leave</h2><span>Your approved time off</span></div><CalendarDays size={20}/></div>
        <div className="upcoming">
          <div className="date-tile"><strong>21</strong><span>SEP</span></div>
          <div><strong>Annual Leave</strong><p>21 Sep – 25 Sep · 5 days</p></div>
          <span className="pill approved">Approved</span>
        </div>
        <div className="upcoming">
          <div className="date-tile"><strong>12</strong><span>OCT</span></div>
          <div><strong>Annual Leave</strong><p>12 Oct – 14 Oct · 3 days</p></div>
          <span className="pill pending">Pending</span>
        </div>
      </div>
    </div>

    {(role !== "Employee") && <div className="card">
      <div className="card-head"><div><h2>Requests needing your attention</h2><span>Manager approvals</span></div><button className="link-btn">View all</button></div>
      <RequestsTable requests={requests.filter(r => r.status === "Pending").slice(0,3)} updateRequest={updateRequest}/>
    </div>}
  </>
}

function Stat({icon,label,value,hint}) {
  return <div className="stat-card"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{hint}</small></div></div>
}
function Balance({label,used,pct}) {
  return <div className="bar-row"><div><span>{label}</span><small>{used}</small></div><div className="bar"><i style={{width:`${pct}%`}}/></div></div>
}

function MyLeave({requests,onRequest}) {
  const mine = requests.filter(r => r.employee === "You" || r.employee === "Nobuhle Makhanya");
  return <>
    <PageHeader eyebrow="MY LEAVE" title="Leave history" subtitle="Review your requests, balances and upcoming time off." action={<button className="primary-btn" onClick={onRequest}><Plus size={18}/> Request leave</button>}/>
    <div className="card"><RequestsTable requests={mine.length ? mine : [{id:99,employee:"Nobuhle Makhanya",type:"Annual Leave",from:"12 Oct 2026",to:"14 Oct 2026",days:3,status:"Pending"}]} /></div>
  </>
}

function Requests({requests,updateRequest,teamOnly=false}) {
  const list = teamOnly ? requests.filter(r => r.employee !== "You") : requests;
  return <>
    <PageHeader eyebrow={teamOnly ? "TEAM LEAVE" : "LEAVE REQUESTS"} title={teamOnly ? "Team requests" : "Leave requests"} subtitle="Review and manage employee time-off requests."/>
    <div className="card"><RequestsTable requests={list} updateRequest={updateRequest}/></div>
  </>
}

function RequestsTable({requests,updateRequest}) {
  return <div className="table-wrap"><table><thead><tr><th>Employee</th><th>Leave type</th><th>Dates</th><th>Days</th><th>Status</th><th></th></tr></thead>
  <tbody>{requests.map(r => <tr key={r.id}><td><div className="person"><div className="mini-avatar">{r.employee.split(" ").map(x=>x[0]).join("").slice(0,2)}</div><strong>{r.employee}</strong></div></td><td>{r.type}</td><td>{r.from} – {r.to}</td><td>{r.days}</td><td><span className={`pill ${r.status.toLowerCase()}`}>{r.status}</span></td><td>{r.status==="Pending" && updateRequest ? <div className="row-actions"><button title="Approve" onClick={()=>updateRequest(r.id,"Approved")}><CheckCircle2 size={18}/></button><button title="Decline" onClick={()=>updateRequest(r.id,"Declined")}><XCircle size={18}/></button></div> : null}</td></tr>)}</tbody></table></div>
}

function LeaveForm({onSubmit}) {
  return <div className="form-card"><PageHeader eyebrow="TIME OFF" title="Request leave" subtitle="Choose your leave type and dates. Your manager will be notified."/>
    <form onSubmit={onSubmit}>
      <label>Leave type<select name="type" required><option>Annual Leave</option><option>Sick Leave</option><option>Family Responsibility</option><option>Study Leave</option><option>Unpaid Leave</option></select></label>
      <div className="form-grid"><label>Start date<input type="date" name="from" required defaultValue="2026-09-21"/></label><label>End date<input type="date" name="to" required defaultValue="2026-09-25"/></label></div>
      <label>Working days<input type="number" name="days" min="1" max="60" defaultValue="5" required/></label>
      <label>Reason <span className="optional">(optional)</span><textarea name="reason" rows="4" placeholder="Add a short note for your manager..."/></label>
      <div className="form-footer"><button type="button" className="secondary-btn" onClick={()=>history.back()}>Cancel</button><button className="primary-btn" type="submit">Submit request</button></div>
    </form>
  </div>
}

function Employees() {
  const employees = [["Nobuhle Makhanya","Marketing","Active"],["Thabo Mokoena","Network Services","Active"],["Nandi Dlamini","Finance","Active"],["Sipho Khumalo","Operations","On leave"],["Ayanda Ndlovu","Human Resources","Active"]];
  return <><PageHeader eyebrow="PEOPLE" title="Employees" subtitle="Manage your workforce and employee records." action={<button className="primary-btn"><Plus size={18}/> Add employee</button>}/><div className="card"><RequestsTable requests={employees.map((e,i)=>({id:i,employee:e[0],type:e[1],from:"",to:"",days:"",status:e[2]}))}/></div></>
}

function Calendar() {
  return <><PageHeader eyebrow="CALENDAR" title="Leave calendar" subtitle="See approved and pending leave across your organization."/><div className="calendar-card"><div className="calendar-title"><button>‹</button><h2>September 2026</h2><button>›</button></div><div className="week">{["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map(d=><span key={d}>{d}</span>)}</div><div className="days">{Array.from({length:30},(_,i)=><div className={`day ${[7,8,9,10].includes(i+1)?"leave":""} ${i+1===5?"today":""}`} key={i}><span>{i+1}</span>{[8,9,10].includes(i+1)&&<small>Thabo</small>}</div>)}</div></div></>
}

function Reports() {
  return <><PageHeader eyebrow="INSIGHTS" title="Reports" subtitle="A quick view of workforce leave trends."/><div className="grid-2"><div className="card chart-card"><h2>Leave usage</h2><div className="fake-chart">{[35,58,44,72,52,84,61,76,48,68,57,81].map((h,i)=><i key={i} style={{height:`${h}%`}}/>)}</div><div className="chart-labels">{["J","F","M","A","M","J","J","A","S","O","N","D"].map(x=><span key={x}>{x}</span>)}</div></div><div className="card"><h2>Leave by type</h2><div className="metric-list"><div><span>Annual Leave</span><strong>68%</strong></div><div><span>Sick Leave</span><strong>18%</strong></div><div><span>Family Responsibility</span><strong>9%</strong></div><div><span>Other</span><strong>5%</strong></div></div></div></div></>
}

function SettingsPage() {
  return <><PageHeader eyebrow="ADMINISTRATION" title="Settings" subtitle="Configure your StaffSync workspace."/><div className="settings-list">{["Company profile","Leave policies","Departments & teams","Roles & permissions","Notifications","Security"].map((x,i)=><div className="setting-row" key={x}><div className="setting-icon">{i===5?<ShieldCheck size={20}/>:<Settings size={20}/>}</div><div><strong>{x}</strong><p>Configure {x.toLowerCase()} for your organization.</p></div><ChevronDown size={18}/></div>)}</div></>
}

function Modal({children,onClose}) {
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal" onMouseDown={e=>e.stopPropagation()}><button className="modal-close" onClick={onClose}>×</button>{children}</div></div>
}

createRoot(document.getElementById("root")).render(<App />);
