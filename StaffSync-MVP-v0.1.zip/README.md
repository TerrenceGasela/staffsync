# StaffSync MVP

A frontend prototype for the StaffSync workforce management platform.

## Included in this first build

- Employee / Manager / HR/Admin role switcher
- Responsive StaffSync shell and navigation
- Employee dashboard
- Leave balance cards
- Leave request form
- Leave request history
- Manager/HR approval and decline actions
- Employee list
- Leave calendar
- Basic reports
- Settings area
- StaffSync branding and slogan

## Run locally

Requirements:
- Node.js 18+ recommended

Commands:

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Important

This is the **UI/MVP prototype**, not yet a production HR system. Authentication, database persistence, real leave rules, POPIA controls, email notifications, audit logging, API/backend and deployment will be added in the next phases.
